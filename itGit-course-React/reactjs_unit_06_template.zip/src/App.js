import './App.css';

function App() {
  return (
    <>
      <Homework1 />
    </>
  );
}

export default App;
