// import logo from './logo.svg';
import "./App.css";
import In from "./In";
import Out from "./Out";
import TextOut from "./TextOut";

function App() {
  return (
    <div className="App">
      <In />
      <Out />
      <TextOut />
    </div>
  );
}

export default App;
