const initialState = {
  users: [
    {
      passport: "156151",
      name: "Dima",
      age: "35",
    },
  ],
};

export default initialState;
