function Error() {
    return (
      <div className="flex-height">
      <img style={{maxWidth: "100%", margin:'20px auto', display:"block"}} src="../img/page_404.jpg" alt="error 404" />
      </div>
    );
  }
  
  export default Error;