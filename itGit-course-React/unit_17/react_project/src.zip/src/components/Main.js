function Main() {
    return (
      <div className="flex-height main-components">
        <h1>Главная страница</h1>
        <p>Создание временной ссылки для передачи информации</p>
      <div>
        <a href='/create'>Создать note</a>
      </div>
       <div>
       <a href='/note'>Просмотреть note</a>
     </div>
     </div>
    );
  }
  
  export default Main;