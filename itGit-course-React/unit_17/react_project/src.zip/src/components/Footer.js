function Footer() {
    return (
      <div className="footer">
        <p>Footer Предназначен для вывода разной информации сайта. </p>
      </div>
    );
  }
  
  export default Footer;