

function About() {
  return (
    <div className="flex-height about">
      <p>Этот сайт создан как практическое задание по курсу сайта itgid.info, в изучении библиотеки React</p>
      <img style={{maxWidth: "100%", margin:'0 auto', display:"block"}} src="../img/react.png" alt="react" />
    </div>
  );
}

export default About;