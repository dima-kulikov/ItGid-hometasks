
import './App.css';
import Homework1 from './Homework1';

function App() {
  return (
  <>
  <Homework1 p1={88}/>
  </>
  );
}

export default App;
